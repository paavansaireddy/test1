class Node:
    def __init__(self, data =None, next=None):
        self.data=data
        self.next=next
    

class LinkedList:
    def __init__(self):
        self.head=None
    
    def insert_at_beg(self, data):
        node=Node(data, self.head)
        self.head=node 
    
    def insert_at_end(self, data):
        if self.head==None:
            self.head=Node(data, self.head)
        
        else:
            lst=self.head
            while(lst.next!=None):
                lst=lst.next
            lst.next=Node(data, lst.next)
    
    def insert_after(self, data, data_after):
        lst=self.head
        flag=0
        if lst==None:
            self.head=Node(data, self.head)
        else:
            while(lst):
                if lst.data==data_after:
                    node=Node(data, lst.next)
                    lst.next=node
                    flag=1
                    break
                lst=lst.next
            if flag==0:
                print("Element Not found")
    def delete_element(self, data):
        if self.head==None:
            print("Nothing to delete here, list is emplty!")
        elif(self.head.data==data):
            self.head=None
        else:
            lst=self.head
            flag=0
            while(lst):
                if lst.next.data==data:
                    lst.next=lst.next.next
                    flag=1
                    break
            if flag==0:
                print("Element not found")
                    
        
    def print_ll(self):
        if self.head==None:
            print("List is empty")
        prn=self.head
        while (prn):
            print(prn.data)
            prn=prn.next
ll=LinkedList()
# ll.insert_at_beg(5)
# ll.insert_at_beg(6)
# ll.insert_after(9,6)
ll.insert_after(11, 9)
ll.insert_after(12, 5)
ll.insert_at_end(7)
ll.print_ll()
print("After deletion")
ll.delete_element(7)
ll.print_ll()
    